import SwiftUI

@Observable
public final class AppEnvironment {
    public let navigationCoordinator = NavigationCoordinator()
    public let cameraManager = CameraManager()
    public let visionManager = VisionManager()
    public let revenueCatManager = RevenueCatManager()
    public var currentSession = ClassroomSession()

    public init() {}
}

public struct AppEnvironmentKey: EnvironmentKey {
    public static let defaultValue = AppEnvironment()
}

extension EnvironmentValues {
    public var appEnvironment: AppEnvironment {
        get { self[AppEnvironmentKey.self] }
        set { self[AppEnvironmentKey.self] = newValue }
    }
}
