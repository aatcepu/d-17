import SwiftUI

public struct RootView: View {
    @State private var env = AppEnvironment()

    public init() {}

    public var body: some View {
        ZStack {
            switch env.navigationCoordinator.currentDestination {
            case .splash:
                SplashView()
            case .onboarding:
                OnboardingView()
            case .teacherSetup:
                TeacherSetupView()
            case .cameraCalibration:
                CameraCalibrationView()
            case .studentDetection:
                StudentDetectionView()
            case .letterAssignment:
                LetterAssignmentView()
            case .humanAnagram:
                HumanAnagramView()
            case .success:
                SuccessView()
            case .results:
                ResultsView()
            case .profile:
                ProfileView()
            case .expansionPacks:
                ExpansionPacksView()
            }
        }
        .environment(\.appEnvironment, env)
        .preferredColorScheme(.dark)
    }
}

#Preview {
    RootView()
}
