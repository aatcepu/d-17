import Foundation
import CoreGraphics
import SwiftUI

/// Represents a student detected in 2D/3D camera space by Apple Vision body pose detection.
public struct Student: Identifiable, Hashable, Equatable, Codable {
    public let id: UUID
    public var name: String
    public var assignedLetter: String?
    public var colorHex: String
    public var normalizedPosition: CGPoint // (0..1, 0..1)
    public var confidence: Float
    public var isTracked: Bool
    public var targetSlotIndex: Int?
    public var isCorrectlyPositioned: Bool

    public var themeColor: Color {
        Color(hex: colorHex) ?? .indigo
    }

    public init(
        id: UUID = UUID(),
        name: String,
        assignedLetter: String? = nil,
        colorHex: String = "#7C3AED",
        normalizedPosition: CGPoint = CGPoint(x: 0.5, y: 0.5),
        confidence: Float = 0.95,
        isTracked: Bool = true,
        targetSlotIndex: Int? = nil,
        isCorrectlyPositioned: Bool = false
    ) {
        self.id = id
        self.name = name
        self.assignedLetter = assignedLetter
        self.colorHex = colorHex
        self.normalizedPosition = normalizedPosition
        self.confidence = confidence
        self.isTracked = isTracked
        self.targetSlotIndex = targetSlotIndex
        self.isCorrectlyPositioned = isCorrectlyPositioned
    }
}
