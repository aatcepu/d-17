import Foundation

public struct AnagramChallenge: Identifiable, Hashable, Equatable, Codable {
    public let id: UUID
    public let targetWord: String
    public let scrambledLetters: [String]
    public let hintText: String
    public let category: String
    public let difficulty: DifficultyLevel

    public enum DifficultyLevel: String, Codable, CaseIterable {
        case beginner = "Beginner"
        case intermediate = "Intermediate"
        case advanced = "Advanced"
    }

    public init(
        id: UUID = UUID(),
        targetWord: String,
        scrambledLetters: [String]? = nil,
        hintText: String,
        category: String,
        difficulty: DifficultyLevel = .beginner
    ) {
        self.id = id
        self.targetWord = targetWord.uppercased()
        self.scrambledLetters = scrambledLetters ?? Array(targetWord.uppercased()).map { String($0) }.shuffled()
        self.hintText = hintText
        self.category = category
        self.difficulty = difficulty
    }
}

public struct ClassroomSession: Identifiable, Hashable, Equatable, Codable {
    public let id: UUID
    public var className: String
    public var teacherName: String
    public var gradeLevel: String
    public var wordLength: Int
    public var topic: String
    public var activeChallenge: AnagramChallenge?
    public var startTime: Date
    public var completedChallengesCount: Int
    public var totalAccuracyScore: Double

    public init(
        id: UUID = UUID(),
        className: String = "Grade 3 Alpha",
        teacherName: String = "Ms. Sharma",
        gradeLevel: String = "Grade 3",
        wordLength: Int = 4,
        topic: String = "Animals & Nature",
        activeChallenge: AnagramChallenge? = nil,
        startTime: Date = Date(),
        completedChallengesCount: Int = 0,
        totalAccuracyScore: Double = 94.5
    ) {
        self.id = id
        self.className = className
        self.teacherName = teacherName
        self.gradeLevel = gradeLevel
        self.wordLength = wordLength
        self.topic = topic
        self.activeChallenge = activeChallenge
        self.startTime = startTime
        self.completedChallengesCount = completedChallengesCount
        self.totalAccuracyScore = totalAccuracyScore
    }
}

public struct ExpansionPack: Identifiable, Hashable, Equatable, Codable {
    public let id: String
    public let title: String
    public let subtitle: String
    public let description: String
    public let wordCount: Int
    public let iconName: String
    public let colorHex: String
    public let priceString: String
    public var isUnlocked: Bool
    public let category: String

    public init(
        id: String,
        title: String,
        subtitle: String,
        description: String,
        wordCount: Int,
        iconName: String,
        colorHex: String,
        priceString: String,
        isUnlocked: Bool = false,
        category: String
    ) {
        self.id = id
        self.title = title
        self.subtitle = subtitle
        self.description = description
        self.wordCount = wordCount
        self.iconName = iconName
        self.colorHex = colorHex
        self.priceString = priceString
        self.isUnlocked = isUnlocked
        self.category = category
    }
}
