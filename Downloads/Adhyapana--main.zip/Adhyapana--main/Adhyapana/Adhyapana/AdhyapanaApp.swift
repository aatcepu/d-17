//
//  AdhyapanaApp.swift
//  Adhyapana
//
//  Created by Student on 03/08/26.
//

import SwiftUI

@main
struct AdhyapanaApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}

