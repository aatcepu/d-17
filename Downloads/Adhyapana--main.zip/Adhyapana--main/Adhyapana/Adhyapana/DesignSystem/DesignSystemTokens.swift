import SwiftUI

public enum AppIcons {
    public static let camera = "camera.viewfinder"
    public static let vision = "person.and.background.dotted"
    public static let anagram = "textformat.abc"
    public static let spark = "sparkles"
    public static let play = "play.fill"
    public static let check = "checkmark.circle.fill"
    public static let star = "star.fill"
    public static let profile = "person.crop.circle.fill"
    public static let expansion = "square.stack.3d.up.fill"
    public static let lock = "lock.fill"
    public static let trophy = "trophy.fill"
    public static let chart = "chart.bar.xaxis"
    public static let gear = "gearshape.fill"
    public static let arrowRight = "arrow.right"
    public static let reload = "arrow.triangle.2.circlepath"
}

public enum AppTheme {
    public static let radiusSmall: CGFloat = 10
    public static let radiusMedium: CGFloat = 18
    public static let radiusLarge: CGFloat = 28
    public static let radiusCapsule: CGFloat = 999

    public static let paddingSmall: CGFloat = 12
    public static let paddingMedium: CGFloat = 20
    public static let paddingLarge: CGFloat = 32
}

public enum AppShadows {
    public static func applyGlow(to content: AnyView, color: Color = AppColors.primaryViolet, radius: CGFloat = 20) -> some View {
        content
            .shadow(color: color.opacity(0.45), radius: radius, x: 0, y: 8)
    }
}

public enum AppAnimations {
    public static let bouncy = Animation.spring(response: 0.45, dampingFraction: 0.62, blendDuration: 0)
    public static let snappy = Animation.spring(response: 0.35, dampingFraction: 0.8, blendDuration: 0)
    public static let smooth = Animation.easeInOut(duration: 0.35)
    public static let pulseContinuous = Animation.easeInOut(duration: 1.8).repeatForever(autoreverses: true)
}
