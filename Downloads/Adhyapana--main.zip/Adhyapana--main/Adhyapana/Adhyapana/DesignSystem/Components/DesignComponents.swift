import SwiftUI

// MARK: - Glass Card Container
public struct GlassCard<Content: View>: View {
    let cornerRadius: CGFloat
    let padding: CGFloat
    let borderColor: Color
    let content: Content

    public init(
        cornerRadius: CGFloat = AppTheme.radiusLarge,
        padding: CGFloat = AppTheme.paddingMedium,
        borderColor: Color = AppColors.glassBorder,
        @ViewBuilder content: () -> Content
    ) {
        self.cornerRadius = cornerRadius
        self.padding = padding
        self.borderColor = borderColor
        self.content = content()
    }

    public var body: some View {
        content
            .padding(padding)
            .background(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .fill(AppColors.backgroundCard)
                    .overlay(
                        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                            .strokeBorder(borderColor, lineWidth: 1)
                    )
            )
            .shadow(color: Color.black.opacity(0.3), radius: 15, x: 0, y: 10)
    }
}

// MARK: - Primary Action Button
public struct PrimaryButton: View {
    let title: String
    let icon: String?
    let action: () -> Void

    @State private var isPressed = false

    public init(title: String, icon: String? = AppIcons.arrowRight, action: @escaping () -> Void) {
        self.title = title
        self.icon = icon
        self.action = action
    }

    public var body: some View {
        Button(action: {
            withAnimation(AppAnimations.snappy) {
                isPressed = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                withAnimation(AppAnimations.snappy) {
                    isPressed = false
                }
                action()
            }
        }) {
            HStack(spacing: 12) {
                Text(title)
                    .font(AppTypography.headline)
                    .foregroundColor(.white)
                if let icon = icon {
                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.white)
                }
            }
            .padding(.horizontal, 28)
            .padding(.vertical, 16)
            .background(AppColors.heroGradient)
            .clipShape(Capsule())
            .shadow(color: AppColors.primaryViolet.opacity(0.5), radius: isPressed ? 8 : 18, x: 0, y: isPressed ? 4 : 8)
            .scaleEffect(isPressed ? 0.96 : 1.0)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Secondary Action Button
public struct SecondaryButton: View {
    let title: String
    let icon: String?
    let action: () -> Void

    public init(title: String, icon: String? = nil, action: @escaping () -> Void) {
        self.title = title
        self.icon = icon
        self.action = action
    }

    public var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                if let icon = icon {
                    Image(systemName: icon)
                        .font(.system(size: 15, weight: .bold))
                        .foregroundColor(AppColors.textSecondary)
                }
                Text(title)
                    .font(AppTypography.headline)
                    .foregroundColor(AppColors.textPrimary)
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 14)
            .background(
                Capsule()
                    .fill(AppColors.glassBackground)
                    .overlay(Capsule().strokeBorder(AppColors.glassBorder, lineWidth: 1))
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Floating Spatial Letter Card
public struct FloatingLetterCard: View {
    let letter: String
    let studentName: String?
    let isSelected: Bool
    let isCorrect: Bool

    @State private var hoverOffset: CGFloat = 0

    public init(letter: String, studentName: String? = nil, isSelected: Bool = false, isCorrect: Bool = false) {
        self.letter = letter
        self.studentName = studentName
        self.isSelected = isSelected
        self.isCorrect = isCorrect
    }

    public var body: some View {
        VStack(spacing: 8) {
            ZStack {
                Circle()
                    .fill(
                        isCorrect
                        ? AppColors.successGradient
                        : (isSelected ? AppColors.heroGradient : LinearGradient(colors: [AppColors.backgroundElevated, AppColors.backgroundCard], startPoint: .top, endPoint: .bottom))
                    )
                    .frame(width: 88, height: 88)
                    .overlay(
                        Circle()
                            .strokeBorder(isCorrect ? AppColors.accentEmerald : (isSelected ? AppColors.accentCyan : AppColors.glassBorder), lineWidth: isSelected || isCorrect ? 3 : 1)
                    )
                    .shadow(color: isCorrect ? AppColors.accentEmerald.opacity(0.6) : (isSelected ? AppColors.primaryViolet.opacity(0.5) : Color.black.opacity(0.3)), radius: isSelected || isCorrect ? 20 : 10)

                Text(letter.uppercased())
                    .font(AppTypography.letterNode)
                    .foregroundColor(.white)
            }
            .offset(y: hoverOffset)
            .onAppear {
                withAnimation(Animation.easeInOut(duration: 2.2).repeatForever(autoreverses: true)) {
                    hoverOffset = -6
                }
            }

            if let studentName = studentName {
                Text(studentName)
                    .font(AppTypography.caption)
                    .foregroundColor(AppColors.textSecondary)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Capsule().fill(Color.black.opacity(0.4)))
            }
        }
    }
}

// MARK: - Step Progress Bar
public struct StepProgressView: View {
    let currentStep: Int
    let totalSteps: Int

    public init(currentStep: Int, totalSteps: Int = 11) {
        self.currentStep = currentStep
        self.totalSteps = totalSteps
    }

    public var body: some View {
        HStack(spacing: 6) {
            ForEach(1...totalSteps, id: \.self) { step in
                Capsule()
                    .fill(step <= currentStep ? AppColors.accentCyan : Color.white.opacity(0.15))
                    .frame(height: 6)
                    .frame(maxWidth: .infinity)
                    .shadow(color: step == currentStep ? AppColors.accentCyan.opacity(0.8) : Color.clear, radius: 4)
            }
        }
        .padding(.horizontal)
    }
}

// MARK: - Dynamic Ambient Mesh Background
public struct DynamicMeshBackground: View {
    @State private var animateBackground = false

    public init() {}

    public var body: some View {
        ZStack {
            AppColors.backgroundDark
                .ignoresSafeArea()

            Circle()
                .fill(AppColors.primaryViolet.opacity(0.25))
                .frame(width: 550, height: 550)
                .blur(radius: 90)
                .offset(x: animateBackground ? -150 : 150, y: animateBackground ? -200 : 200)

            Circle()
                .fill(AppColors.accentCyan.opacity(0.20))
                .frame(width: 450, height: 450)
                .blur(radius: 80)
                .offset(x: animateBackground ? 200 : -180, y: animateBackground ? 180 : -150)

            Circle()
                .fill(AppColors.accentRose.opacity(0.15))
                .frame(width: 400, height: 400)
                .blur(radius: 100)
                .offset(x: animateBackground ? 50 : -50, y: animateBackground ? -100 : 100)
        }
        .onAppear {
            withAnimation(Animation.easeInOut(duration: 10.0).repeatForever(autoreverses: true)) {
                animateBackground.toggle()
            }
        }
    }
}

// MARK: - Status Badge
public struct StatusBadge: View {
    let text: String
    let icon: String?
    let color: Color

    public init(text: String, icon: String? = nil, color: Color = AppColors.accentCyan) {
        self.text = text
        self.icon = icon
        self.color = color
    }

    public var body: some View {
        HStack(spacing: 6) {
            if let icon = icon {
                Image(systemName: icon)
                    .font(.system(size: 11, weight: .bold))
            }
            Text(text.uppercased())
                .font(AppTypography.caption)
                .fontWeight(.bold)
        }
        .foregroundColor(color)
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(color.opacity(0.15))
        .overlay(Capsule().strokeBorder(color.opacity(0.3), lineWidth: 1))
        .clipShape(Capsule())
    }
}
