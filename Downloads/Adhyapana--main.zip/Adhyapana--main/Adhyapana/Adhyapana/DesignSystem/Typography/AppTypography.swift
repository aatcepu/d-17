import SwiftUI

public enum AppTypography {
    public static let displayHero = Font.system(size: 48, weight: .black, design: .rounded)
    public static let title1 = Font.system(size: 32, weight: .bold, design: .rounded)
    public static let title2 = Font.system(size: 24, weight: .bold, design: .rounded)
    public static let title3 = Font.system(size: 20, weight: .semibold, design: .rounded)
    public static let headline = Font.system(size: 17, weight: .semibold, design: .rounded)
    public static let body = Font.system(size: 15, weight: .regular, design: .default)
    public static let caption = Font.system(size: 13, weight: .medium, design: .default)
    public static let monospacedBadge = Font.system(size: 14, weight: .bold, design: .monospaced)
    public static let letterNode = Font.system(size: 54, weight: .black, design: .rounded)
}
