import SwiftUI

public enum AppColors {
    // Primary Midnight Deep Space Gradients & Fills
    public static let backgroundDark = Color(red: 0.04, green: 0.04, blue: 0.08)
    public static let backgroundCard = Color(red: 0.09, green: 0.09, blue: 0.16).opacity(0.7)
    public static let backgroundElevated = Color(red: 0.12, green: 0.12, blue: 0.22).opacity(0.85)

    // Brand Neon Vibrancies
    public static let primaryViolet = Color(red: 0.55, green: 0.35, blue: 0.98)
    public static let primaryIndigo = Color(red: 0.38, green: 0.40, blue: 0.95)
    public static let accentCyan = Color(red: 0.20, green: 0.85, blue: 0.95)
    public static let accentEmerald = Color(red: 0.16, green: 0.85, blue: 0.53)
    public static let accentAmber = Color(red: 1.00, green: 0.73, blue: 0.20)
    public static let accentRose = Color(red: 0.98, green: 0.32, blue: 0.52)

    // Text & Labels
    public static let textPrimary = Color.white
    public static let textSecondary = Color.white.opacity(0.72)
    public static let textMuted = Color.white.opacity(0.45)

    // Glass Borders & Highlights
    public static let glassBorder = Color.white.opacity(0.18)
    public static let glassBorderActive = Color.white.opacity(0.40)
    public static let glassBackground = Color.white.opacity(0.06)

    // Gradients
    public static let heroGradient = LinearGradient(
        colors: [primaryViolet, primaryIndigo, accentCyan],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    public static let successGradient = LinearGradient(
        colors: [accentEmerald, Color(red: 0.05, green: 0.70, blue: 0.45)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    public static let goldGradient = LinearGradient(
        colors: [accentAmber, Color(red: 0.95, green: 0.55, blue: 0.10)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    public static let ambientGlow = RadialGradient(
        colors: [primaryViolet.opacity(0.35), Color.clear],
        center: .center,
        startRadius: 10,
        endRadius: 350
    )
}

extension Color {
    init?(hex: String) {
        let hexCleaned = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hexCleaned).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hexCleaned.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            return nil
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}
