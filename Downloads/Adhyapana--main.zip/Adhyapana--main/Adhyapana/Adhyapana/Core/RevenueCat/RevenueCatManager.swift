import SwiftUI

@Observable
public final class RevenueCatManager {
    public var isProSubscriber: Bool = false
    public var activeExpansionPacks: Set<String> = ["pack_phonics_pioneers"]
    public var expansionPacks: [ExpansionPack] = AppConstants.sampleExpansionPacks

    public init() {}

    public func unlockPack(id: String) {
        if let idx = expansionPacks.firstIndex(where: { $0.id == id }) {
            expansionPacks[idx].isUnlocked = true
            activeExpansionPacks.insert(id)
        }
    }

    public func purchaseProSubscription() {
        withAnimation(AppAnimations.smooth) {
            isProSubscriber = true
            for i in 0..<expansionPacks.count {
                expansionPacks[i].isUnlocked = true
                activeExpansionPacks.insert(expansionPacks[i].id)
            }
        }
    }
}
