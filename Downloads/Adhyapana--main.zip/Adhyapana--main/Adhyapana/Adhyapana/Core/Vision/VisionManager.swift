import Vision
import CoreGraphics
import SwiftUI

@Observable
public final class VisionManager {
    public var detectedStudents: [Student] = []
    public var detectedBodyCount: Int = 0
    public var isProcessing: Bool = false
    public var currentSpatialWord: String = ""

    private var simulatedTimer: Timer?

    public init() {
        self.detectedStudents = AppConstants.defaultStudents
        self.detectedBodyCount = AppConstants.defaultStudents.count
    }

    public func startPoseDetection() {
        isProcessing = true
    }

    public func stopPoseDetection() {
        isProcessing = false
        simulatedTimer?.invalidate()
        simulatedTimer = nil
    }

    /// Sorts tracked students horizontally from Left to Right (X axis) to evaluate spatial anagram arrangement.
    public func updateSpatialSorting() {
        detectedStudents.sort { $0.normalizedPosition.x < $1.normalizedPosition.x }
        let currentLetters = detectedStudents.compactMap { $0.assignedLetter }
        currentSpatialWord = currentLetters.joined()
    }

    public func simulateStudentSwap(indexA: Int, indexB: Int) {
        guard indexA >= 0 && indexA < detectedStudents.count,
              indexB >= 0 && indexB < detectedStudents.count else { return }

        let tempPos = detectedStudents[indexA].normalizedPosition
        detectedStudents[indexA].normalizedPosition = detectedStudents[indexB].normalizedPosition
        detectedStudents[indexB].normalizedPosition = tempPos

        updateSpatialSorting()
    }

    public func assignLettersToStudents(for targetWord: String) {
        let charArray = Array(targetWord.uppercased()).map { String($0) }
        for i in 0..<detectedStudents.count {
            if i < charArray.count {
                detectedStudents[i].assignedLetter = charArray[i]
            }
        }
        updateSpatialSorting()
    }
}
