import SwiftUI

public enum NavigationDestination: String, Hashable, CaseIterable, Identifiable {
    case splash = "Splash"
    case onboarding = "Onboarding"
    case teacherSetup = "Teacher Setup"
    case cameraCalibration = "Camera Calibration"
    case studentDetection = "Student Detection"
    case letterAssignment = "Letter Assignment"
    case humanAnagram = "Human Anagram Activity"
    case success = "Success Celebration"
    case results = "Results"
    case profile = "Profile"
    case expansionPacks = "Expansion Packs"

    public var id: String { rawValue }

    public var stepIndex: Int {
        switch self {
        case .splash: return 1
        case .onboarding: return 2
        case .teacherSetup: return 3
        case .cameraCalibration: return 4
        case .studentDetection: return 5
        case .letterAssignment: return 6
        case .humanAnagram: return 7
        case .success: return 8
        case .results: return 9
        case .profile: return 10
        case .expansionPacks: return 11
        }
    }
}

@Observable
public final class NavigationCoordinator {
    public var currentDestination: NavigationDestination = .splash
    public var path = NavigationPath()

    public init() {}

    public func navigateTo(_ destination: NavigationDestination) {
        withAnimation(AppAnimations.smooth) {
            currentDestination = destination
        }
    }

    public func nextStep() {
        let all = NavigationDestination.allCases
        if let idx = all.firstIndex(of: currentDestination), idx + 1 < all.count {
            navigateTo(all[idx + 1])
        }
    }

    public func previousStep() {
        let all = NavigationDestination.allCases
        if let idx = all.firstIndex(of: currentDestination), idx > 0 {
            navigateTo(all[idx - 1])
        }
    }
}
