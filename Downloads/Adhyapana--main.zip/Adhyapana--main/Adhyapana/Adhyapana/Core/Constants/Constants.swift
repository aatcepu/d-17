import Foundation

public enum AppConstants {
    public static let appName = "Adhyāpana"
    public static let appTagline = "The Classroom is the Interface"
    public static let sanskritTitle = "अध्यापन"
    public static let revenueCatAPIKey = "appl_adhyapana_revenuecat_2026_demo"

    public static let defaultStudents: [Student] = [
        Student(name: "Aarav", colorHex: "#7C3AED", normalizedPosition: CGPoint(x: 0.22, y: 0.50)),
        Student(name: "Diya", colorHex: "#3B82F6", normalizedPosition: CGPoint(x: 0.42, y: 0.50)),
        Student(name: "Kabir", colorHex: "#10B981", normalizedPosition: CGPoint(x: 0.62, y: 0.50)),
        Student(name: "Ananya", colorHex: "#F59E0B", normalizedPosition: CGPoint(x: 0.82, y: 0.50))
    ]

    public static let sampleChallenges: [AnagramChallenge] = [
        AnagramChallenge(targetWord: "CAT", scrambledLetters: ["T", "A", "C"], hintText: "A furry domestic pet that meows", category: "Animals"),
        AnagramChallenge(targetWord: "STAR", scrambledLetters: ["R", "A", "T", "S"], hintText: "Shines brightly in the night sky", category: "Astronomy"),
        AnagramChallenge(targetWord: "PLANT", scrambledLetters: ["N", "T", "L", "A", "P"], hintText: "Grows in soil using sunlight", category: "Nature"),
        AnagramChallenge(targetWord: "SOLAR", scrambledLetters: ["R", "A", "L", "O", "S"], hintText: "Energy derived directly from the Sun", category: "Science")
    ]

    public static let sampleExpansionPacks: [ExpansionPack] = [
        ExpansionPack(
            id: "pack_phonics_pioneers",
            title: "Phonics Pioneers",
            subtitle: "300+ Early Reader Vocabulary Cards",
            description: "Master CVC words, digraphs, and foundational spelling patterns through physical spatial movement.",
            wordCount: 320,
            iconName: "text.book.closed.fill",
            colorHex: "#7C3AED",
            priceString: "Included in Free Tier",
            isUnlocked: true,
            category: "Foundational Literacy"
        ),
        ExpansionPack(
            id: "pack_science_explorer",
            title: "Science & Cosmos Explorer",
            subtitle: "Solar System, Biology & Physics Anagrams",
            description: "Turn complex scientific terms into active spatial puzzles for elementary and middle schoolers.",
            wordCount: 450,
            iconName: "atom",
            colorHex: "#06B6D4",
            priceString: "$4.99 / mo or unlocked with Pro",
            isUnlocked: false,
            category: "STEM Education"
        ),
        ExpansionPack(
            id: "pack_math_crafters",
            title: "Math & Equation Crafters",
            subtitle: "Numbers, Operators & Mathematical Logic",
            description: "Students line up physically to build valid arithmetic equations and solve algebraic challenges.",
            wordCount: 250,
            iconName: "function",
            colorHex: "#10B981",
            priceString: "$4.99 / mo or unlocked with Pro",
            isUnlocked: false,
            category: "Mathematics"
        ),
        ExpansionPack(
            id: "pack_global_polyglot",
            title: "Global Polyglot Edition",
            subtitle: "Multilingual Phonics in Hindi, Spanish & French",
            description: "Empower bilingual classrooms with real-time multi-script optical body movement exercises.",
            wordCount: 600,
            iconName: "globe.americas.fill",
            colorHex: "#F59E0B",
            priceString: "$7.99 / mo or unlocked with Pro",
            isUnlocked: false,
            category: "World Languages"
        )
    ]
}
