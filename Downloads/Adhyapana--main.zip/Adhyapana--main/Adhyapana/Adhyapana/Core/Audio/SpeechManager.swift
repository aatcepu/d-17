import AVFoundation
import SwiftUI

public final class SpeechManager: NSObject, AVSpeechSynthesizerDelegate {
    public static let shared = SpeechManager()

    private let synthesizer = AVSpeechSynthesizer()

    public override init() {
        super.init()
        synthesizer.delegate = self
    }

    public func speak(_ text: String, pitch: Float = 1.1, rate: Float = AVSpeechUtteranceDefaultSpeechRate * 0.9) {
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        utterance.pitchMultiplier = pitch
        utterance.rate = rate
        synthesizer.speak(utterance)
    }

    public func speakPhonetic(letter: String) {
        speak("Letter \(letter.uppercased())!")
    }

    public func celebrateWordSuccess(word: String) {
        speak("Wonderful! You spelled \(word.uppercased())! Great job team!")
    }
}
