import SwiftUI

public struct OnboardingView: View {
    @Environment(\.appEnvironment) private var env
    @State private var selectedTab: Int = 0

    private let pages: [(title: String, subtitle: String, icon: String, detail: String)] = [
        ("The Classroom is the Interface", "Turn physical movement into active learning.", AppIcons.vision, "Zero individual screens. Children stand together, move in space, and learn through physical collaboration."),
        ("Zero Wearables Required", "Powered entirely by on-device Apple Vision.", AppIcons.camera, "A single iPad mounted at the front of the room tracks body poses in real-time with total privacy."),
        ("Active Human Anagrams", "Students become the letters of the word.", AppIcons.spark, "By moving left and right, students rearrange live floating letter nodes to solve spelling challenges together.")
    ]

    public init() {}

    public var body: some View {
        ZStack {
            DynamicMeshBackground()

            VStack(spacing: 32) {
                // Top Header Progress Bar
                HStack {
                    StepProgressView(currentStep: 2, totalSteps: 11)
                }
                .padding(.top, 20)

                TabView(selection: $selectedTab) {
                    ForEach(0..<pages.count, id: \.self) { index in
                        GlassCard {
                            VStack(spacing: 28) {
                                Image(systemName: pages[index].icon)
                                    .font(.system(size: 80, weight: .semibold))
                                    .foregroundStyle(AppColors.heroGradient)
                                    .frame(height: 120)

                                VStack(spacing: 12) {
                                    Text(pages[index].title)
                                        .font(AppTypography.title1)
                                        .foregroundColor(AppColors.textPrimary)
                                        .multilineTextAlignment(.center)

                                    Text(pages[index].subtitle)
                                        .font(AppTypography.headline)
                                        .foregroundColor(AppColors.accentCyan)
                                        .multilineTextAlignment(.center)

                                    Text(pages[index].detail)
                                        .font(AppTypography.body)
                                        .foregroundColor(AppColors.textSecondary)
                                        .multilineTextAlignment(.center)
                                        .padding(.horizontal, 20)
                                }
                            }
                            .padding(.vertical, 30)
                        }
                        .padding(.horizontal, 30)
                        .tag(index)
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: .always))
                .frame(maxHeight: 520)

                HStack(spacing: 20) {
                    if selectedTab > 0 {
                        SecondaryButton(title: "Previous") {
                            withAnimation { selectedTab -= 1 }
                        }
                    }

                    PrimaryButton(title: selectedTab == pages.count - 1 ? "Setup Session" : "Next Page") {
                        if selectedTab < pages.count - 1 {
                            withAnimation { selectedTab += 1 }
                        } else {
                            env.navigationCoordinator.navigateTo(.teacherSetup)
                        }
                    }
                }
                .padding(.bottom, 30)
            }
        }
    }
}
