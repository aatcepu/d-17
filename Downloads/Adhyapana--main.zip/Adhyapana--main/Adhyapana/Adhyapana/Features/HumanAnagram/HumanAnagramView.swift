import SwiftUI

public struct HumanAnagramView: View {
    @Environment(\.appEnvironment) private var env
    @State private var timeRemaining: Int = 45
    @State private var timer: Timer?
    @State private var isSolved: Bool = false

    public init() {}

    public var body: some View {
        ZStack {
            DynamicMeshBackground()

            VStack(spacing: 20) {
                // Top HUD Bar
                HStack {
                    StepProgressView(currentStep: 7, totalSteps: 11)
                }
                .padding(.top, 16)

                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("TARGET WORD")
                            .font(AppTypography.caption)
                            .foregroundColor(AppColors.textMuted)
                        Text(env.currentSession.activeChallenge?.targetWord ?? "CAT")
                            .font(AppTypography.title1)
                            .foregroundColor(AppColors.accentCyan)
                    }

                    Spacer()

                    // Live Timer Pill
                    HStack(spacing: 8) {
                        Image(systemName: "timer")
                            .font(.system(size: 18, weight: .bold))
                        Text("\(timeRemaining)s")
                            .font(AppTypography.monospacedBadge)
                            .font(.system(size: 20))
                    }
                    .foregroundColor(timeRemaining < 10 ? AppColors.accentRose : AppColors.accentAmber)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(Capsule().fill(Color.black.opacity(0.4)))

                    Spacer()

                    VStack(alignment: .trailing, spacing: 4) {
                        Text("CURRENT SPATIAL ORDER")
                            .font(AppTypography.caption)
                            .foregroundColor(AppColors.textMuted)
                        Text(env.visionManager.currentSpatialWord.isEmpty ? "T A C" : env.visionManager.currentSpatialWord)
                            .font(AppTypography.title2)
                            .foregroundColor(isSolved ? AppColors.accentEmerald : AppColors.accentRose)
                    }
                }
                .padding(.horizontal, 32)

                // Central Interactive Spatial Stage Area
                GlassCard {
                    VStack(spacing: 24) {
                        Text(env.currentSession.activeChallenge?.hintText ?? "Move left or right in physical space to arrange letters!")
                            .font(AppTypography.headline)
                            .foregroundColor(AppColors.textSecondary)
                            .multilineTextAlignment(.center)

                        // Interactive Letter Nodes representing physical students on stage
                        HStack(spacing: 40) {
                            ForEach(Array(env.visionManager.detectedStudents.enumerated()), id: \.element.id) { index, student in
                                FloatingLetterCard(
                                    letter: student.assignedLetter ?? "?",
                                    studentName: student.name,
                                    isSelected: true,
                                    isCorrect: isSolved
                                )
                                .onTapGesture {
                                    // Interactive tap simulate student swapping physical positions
                                    if index + 1 < env.visionManager.detectedStudents.count {
                                        env.visionManager.simulateStudentSwap(indexA: index, indexB: index + 1)
                                    } else {
                                        env.visionManager.simulateStudentSwap(indexA: index, indexB: 0)
                                    }
                                    checkAnagramSolution()
                                }
                            }
                        }
                        .padding(.vertical, 20)

                        Text("💡 Tap letter node or physically move students in room to re-order!")
                            .font(AppTypography.caption)
                            .foregroundColor(AppColors.accentCyan)
                    }
                }
                .padding(.horizontal, 30)

                // Controls & Action Bar
                HStack(spacing: 20) {
                    SecondaryButton(title: "Simulate Physical Swap", icon: AppIcons.reload) {
                        if env.visionManager.detectedStudents.count >= 2 {
                            env.visionManager.simulateStudentSwap(indexA: 0, indexB: 1)
                            checkAnagramSolution()
                        }
                    }

                    PrimaryButton(title: "Complete Challenge", icon: AppIcons.check) {
                        SpeechManager.shared.celebrateWordSuccess(word: env.currentSession.activeChallenge?.targetWord ?? "CAT")
                        env.navigationCoordinator.navigateTo(.success)
                    }
                }
                .padding(.bottom, 24)
            }
        }
        .onAppear {
            startTimer()
        }
        .onDisappear {
            timer?.invalidate()
        }
    }

    private func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if timeRemaining > 0 {
                timeRemaining -= 1
            }
        }
    }

    private func checkAnagramSolution() {
        if env.visionManager.currentSpatialWord == env.currentSession.activeChallenge?.targetWord {
            withAnimation(AppAnimations.bouncy) {
                isSolved = true
            }
            SpeechManager.shared.speak("Correct arrangement detected!")
        }
    }
}
