import SwiftUI

public struct ExpansionPacksView: View {
    @Environment(\.appEnvironment) private var env
    @State private var showingPaywall: Bool = false
    @State private var selectedPack: ExpansionPack?

    public init() {}

    public var body: some View {
        ZStack {
            DynamicMeshBackground()

            ScrollView {
                VStack(spacing: 28) {
                    StepProgressView(currentStep: 11, totalSteps: 11)
                        .padding(.top, 20)

                    VStack(spacing: 6) {
                        StatusBadge(text: "POWERED BY REVENUECAT", icon: AppIcons.spark, color: AppColors.accentCyan)

                        Text("Curriculum Expansion Packs")
                            .font(AppTypography.title1)
                            .foregroundColor(AppColors.textPrimary)

                        Text("Unlock specialized vocabulary, STEM terms, and multilingual anagrams.")
                            .font(AppTypography.body)
                            .foregroundColor(AppColors.textSecondary)
                    }

                    // Pro Banner Card
                    GlassCard {
                        HStack {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("UNLOCK ALL PACKS WITH PRO")
                                    .font(AppTypography.caption)
                                    .foregroundColor(AppColors.accentAmber)

                                Text("Adhyāpana Educator Pro Pass")
                                    .font(AppTypography.title2)
                                    .foregroundColor(.white)

                                Text("Unlimited curriculum packs, custom word lists, and PDF analytics export.")
                                    .font(AppTypography.body)
                                    .foregroundColor(AppColors.textSecondary)
                            }

                            Spacer()

                            Button(action: {
                                env.revenueCatManager.purchaseProSubscription()
                            }) {
                                Text(env.revenueCatManager.isProSubscriber ? "PRO ACTIVE" : "UPGRADE PRO")
                                    .font(AppTypography.headline)
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 20)
                                    .padding(.vertical, 12)
                                    .background(AppColors.goldGradient)
                                    .clipShape(Capsule())
                                    .shadow(color: AppColors.accentAmber.opacity(0.6), radius: 10)
                            }
                            .disabled(env.revenueCatManager.isProSubscriber)
                        }
                    }
                    .padding(.horizontal, 30)

                    // Expansion Packs List Grid
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                        ForEach(env.revenueCatManager.expansionPacks) { pack in
                            GlassCard {
                                VStack(alignment: .leading, spacing: 14) {
                                    HStack {
                                        Image(systemName: pack.iconName)
                                            .font(.system(size: 32))
                                            .foregroundColor(Color(hex: pack.colorHex) ?? AppColors.primaryViolet)

                                        Spacer()

                                        StatusBadge(
                                            text: pack.isUnlocked ? "UNLOCKED" : "LOCKED",
                                            icon: pack.isUnlocked ? "checkmark.circle.fill" : "lock.fill",
                                            color: pack.isUnlocked ? AppColors.accentEmerald : AppColors.textMuted
                                        )
                                    }

                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(pack.title)
                                            .font(AppTypography.title3)
                                            .foregroundColor(.white)

                                        Text(pack.subtitle)
                                            .font(AppTypography.caption)
                                            .foregroundColor(AppColors.accentCyan)
                                    }

                                    Text(pack.description)
                                        .font(AppTypography.caption)
                                        .foregroundColor(AppColors.textSecondary)
                                        .lineLimit(3)

                                    HStack {
                                        Text("\(pack.wordCount) Words")
                                            .font(AppTypography.monospacedBadge)
                                            .foregroundColor(AppColors.textMuted)

                                        Spacer()

                                        if !pack.isUnlocked {
                                            Button(action: {
                                                env.revenueCatManager.unlockPack(id: pack.id)
                                            }) {
                                                Text("Unlock Pack")
                                                    .font(AppTypography.caption)
                                                    .fontWeight(.bold)
                                                    .foregroundColor(AppColors.primaryViolet)
                                                    .padding(.horizontal, 14)
                                                    .padding(.vertical, 8)
                                                    .background(Capsule().fill(Color.white.opacity(0.12)))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 30)

                    HStack(spacing: 20) {
                        SecondaryButton(title: "Back to Splash", icon: AppIcons.reload) {
                            env.navigationCoordinator.navigateTo(.splash)
                        }

                        PrimaryButton(title: "Restart Session", icon: AppIcons.play) {
                            env.navigationCoordinator.navigateTo(.teacherSetup)
                        }
                    }
                    .padding(.bottom, 40)
                }
            }
        }
    }
}
