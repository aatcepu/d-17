import SwiftUI

public struct ResultsView: View {
    @Environment(\.appEnvironment) private var env

    public init() {}

    public var body: some View {
        ZStack {
            DynamicMeshBackground()

            ScrollView {
                VStack(spacing: 28) {
                    StepProgressView(currentStep: 9, totalSteps: 11)
                        .padding(.top, 20)

                    VStack(spacing: 6) {
                        StatusBadge(text: "Session Complete", icon: AppIcons.check, color: AppColors.accentEmerald)

                        Text("Classroom Performance Analytics")
                            .font(AppTypography.title1)
                            .foregroundColor(AppColors.textPrimary)

                        Text("Comprehensive physical activity report for \(env.currentSession.className)")
                            .font(AppTypography.body)
                            .foregroundColor(AppColors.textSecondary)
                    }

                    // Key Performance Metrics Grid
                    HStack(spacing: 16) {
                        GlassCard {
                            VStack(spacing: 8) {
                                Image(systemName: "timer")
                                    .font(.system(size: 28))
                                    .foregroundColor(AppColors.accentCyan)
                                Text("Avg Speed")
                                    .font(AppTypography.caption)
                                    .foregroundColor(AppColors.textMuted)
                                Text("18.4s")
                                    .font(AppTypography.title2)
                                    .foregroundColor(.white)
                            }
                            .frame(maxWidth: .infinity)
                        }

                        GlassCard {
                            VStack(spacing: 8) {
                                Image(systemName: "figure.walk")
                                    .font(.system(size: 28))
                                    .foregroundColor(AppColors.primaryViolet)
                                Text("Spatial Precision")
                                    .font(AppTypography.caption)
                                    .foregroundColor(AppColors.textMuted)
                                Text("98.2%")
                                    .font(AppTypography.title2)
                                    .foregroundColor(.white)
                            }
                            .frame(maxWidth: .infinity)
                        }

                        GlassCard {
                            VStack(spacing: 8) {
                                Image(systemName: "star.fill")
                                    .font(.system(size: 28))
                                    .foregroundColor(AppColors.accentAmber)
                                Text("Engagement")
                                    .font(AppTypography.caption)
                                    .foregroundColor(AppColors.textMuted)
                                Text("100%")
                                    .font(AppTypography.title2)
                                    .foregroundColor(.white)
                            }
                            .frame(maxWidth: .infinity)
                        }
                    }
                    .padding(.horizontal, 30)

                    // Individual Student Summary Table
                    GlassCard {
                        VStack(alignment: .leading, spacing: 18) {
                            Text("PARTICIPATING STUDENTS")
                                .font(AppTypography.caption)
                                .foregroundColor(AppColors.accentCyan)

                            ForEach(env.visionManager.detectedStudents) { student in
                                HStack {
                                    Circle()
                                        .fill(student.themeColor)
                                        .frame(width: 12, height: 12)

                                    Text(student.name)
                                        .font(AppTypography.headline)
                                        .foregroundColor(.white)

                                    Spacer()

                                    Text("Assigned: '\(student.assignedLetter ?? "-")'")
                                        .font(AppTypography.monospacedBadge)
                                        .foregroundColor(AppColors.textSecondary)

                                    Text("Pacing: Optimal")
                                        .font(AppTypography.caption)
                                        .foregroundColor(AppColors.accentEmerald)
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 4)
                                        .background(Capsule().fill(AppColors.accentEmerald.opacity(0.15)))
                                }
                                Divider()
                                    .background(Color.white.opacity(0.1))
                            }
                        }
                    }
                    .padding(.horizontal, 30)

                    HStack(spacing: 20) {
                        SecondaryButton(title: "Teacher Profile", icon: AppIcons.profile) {
                            env.navigationCoordinator.navigateTo(.profile)
                        }

                        PrimaryButton(title: "Expansion Packs", icon: AppIcons.expansion) {
                            env.navigationCoordinator.navigateTo(.expansionPacks)
                        }
                    }
                    .padding(.bottom, 30)
                }
            }
        }
    }
}
