import SwiftUI

public struct StudentDetectionView: View {
    @Environment(\.appEnvironment) private var env

    public init() {}

    public var body: some View {
        ZStack {
            DynamicMeshBackground()

            VStack(spacing: 24) {
                StepProgressView(currentStep: 5, totalSteps: 11)
                    .padding(.top, 20)

                VStack(spacing: 6) {
                    StatusBadge(text: "Apple Vision Body Pose Active", icon: AppIcons.vision, color: AppColors.accentEmerald)

                    Text("Live Student Detection")
                        .font(AppTypography.title1)
                        .foregroundColor(AppColors.textPrimary)

                    Text("\(env.visionManager.detectedStudents.count) Students Tracked in Physical Stage Space")
                        .font(AppTypography.headline)
                        .foregroundColor(AppColors.accentCyan)
                }

                // Spatial Stage View
                GlassCard {
                    ZStack {
                        RoundedRectangle(cornerRadius: AppTheme.radiusLarge)
                            .fill(Color.black.opacity(0.5))
                            .frame(height: 340)

                        // Tracked Student Avatars
                        HStack(spacing: 30) {
                            ForEach(env.visionManager.detectedStudents) { student in
                                VStack(spacing: 12) {
                                    ZStack {
                                        Circle()
                                            .fill(student.themeColor.opacity(0.3))
                                            .frame(width: 90, height: 90)
                                            .overlay(Circle().strokeBorder(student.themeColor, lineWidth: 3))
                                            .shadow(color: student.themeColor.opacity(0.8), radius: 15)

                                        Image(systemName: "person.fill")
                                            .font(.system(size: 44))
                                            .foregroundColor(.white)
                                    }

                                    VStack(spacing: 2) {
                                        Text(student.name)
                                            .font(AppTypography.headline)
                                            .foregroundColor(.white)
                                        Text("CONF: \(Int(student.confidence * 100))%")
                                            .font(AppTypography.monospacedBadge)
                                            .foregroundColor(AppColors.accentEmerald)
                                    }
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal, 30)

                HStack(spacing: 20) {
                    SecondaryButton(title: "Recalibrate") {
                        env.navigationCoordinator.navigateTo(.cameraCalibration)
                    }

                    PrimaryButton(title: "Assign Letters", icon: AppIcons.anagram) {
                        env.navigationCoordinator.navigateTo(.letterAssignment)
                    }
                }
                .padding(.bottom, 30)
            }
        }
    }
}
