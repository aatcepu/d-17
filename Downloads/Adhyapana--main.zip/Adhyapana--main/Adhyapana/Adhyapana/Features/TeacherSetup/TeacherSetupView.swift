import SwiftUI

public struct TeacherSetupView: View {
    @Environment(\.appEnvironment) private var env

    @State private var className: String = "Grade 3 Alpha"
    @State private var selectedGrade: String = "Grade 3"
    @State private var wordLength: Int = 3
    @State private var selectedTopic: String = "Animals & Nature"

    private let grades = ["Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5"]
    private let topics = ["Animals & Nature", "Space & Astronomy", "Science Explorer", "Basic Math"]

    public init() {}

    public var body: some View {
        ZStack {
            DynamicMeshBackground()

            ScrollView {
                VStack(spacing: 28) {
                    StepProgressView(currentStep: 3, totalSteps: 11)
                        .padding(.top, 20)

                    VStack(spacing: 8) {
                        Text("Teacher Configuration")
                            .font(AppTypography.title1)
                            .foregroundColor(AppColors.textPrimary)

                        Text("Set up your classroom parameters before starting camera tracking.")
                            .font(AppTypography.body)
                            .foregroundColor(AppColors.textSecondary)
                    }

                    GlassCard {
                        VStack(alignment: .leading, spacing: 24) {
                            // Class Name Input
                            VStack(alignment: .leading, spacing: 8) {
                                Text("CLASSROOM NAME")
                                    .font(AppTypography.caption)
                                    .foregroundColor(AppColors.accentCyan)

                                TextField("Class Name", text: $className)
                                    .font(AppTypography.headline)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.08)))
                            }

                            // Grade Selector
                            VStack(alignment: .leading, spacing: 8) {
                                Text("GRADE LEVEL")
                                    .font(AppTypography.caption)
                                    .foregroundColor(AppColors.accentCyan)

                                HStack(spacing: 10) {
                                    ForEach(grades, id: \.self) { grade in
                                        Button(action: { selectedGrade = grade }) {
                                            Text(grade)
                                                .font(AppTypography.caption)
                                                .fontWeight(.bold)
                                                .padding(.horizontal, 14)
                                                .padding(.vertical, 10)
                                                .background(selectedGrade == grade ? AppColors.primaryViolet : Color.white.opacity(0.08))
                                                .foregroundColor(.white)
                                                .clipShape(Capsule())
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }

                            // Target Word Length Selector
                            VStack(alignment: .leading, spacing: 8) {
                                Text("TARGET ANAGRAM WORD LENGTH (STUDENT GROUP SIZE)")
                                    .font(AppTypography.caption)
                                    .foregroundColor(AppColors.accentCyan)

                                HStack(spacing: 16) {
                                    ForEach([3, 4, 5], id: \.self) { length in
                                        Button(action: { wordLength = length }) {
                                            VStack(spacing: 4) {
                                                Text("\(length)")
                                                    .font(AppTypography.title2)
                                                    .foregroundColor(.white)
                                                Text("\(length) Students")
                                                    .font(AppTypography.caption)
                                                    .foregroundColor(AppColors.textSecondary)
                                            }
                                            .frame(maxWidth: .infinity)
                                            .padding(.vertical, 14)
                                            .background(
                                                RoundedRectangle(cornerRadius: 14)
                                                    .fill(wordLength == length ? AppColors.heroGradient : LinearGradient(colors: [Color.white.opacity(0.08)], startPoint: .top, endPoint: .bottom))
                                                    .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(wordLength == length ? AppColors.accentCyan : AppColors.glassBorder, lineWidth: 1))
                                            )
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }

                            // Topic Selection
                            VStack(alignment: .leading, spacing: 8) {
                                Text("LEARNING TOPIC")
                                    .font(AppTypography.caption)
                                    .foregroundColor(AppColors.accentCyan)

                                Picker("Topic", selection: $selectedTopic) {
                                    ForEach(topics, id: \.self) { topic in
                                        Text(topic).tag(topic)
                                    }
                                }
                                .pickerStyle(.segmented)
                            }
                        }
                    }
                    .padding(.horizontal, 30)

                    HStack(spacing: 20) {
                        SecondaryButton(title: "Back") {
                            env.navigationCoordinator.navigateTo(.onboarding)
                        }

                        PrimaryButton(title: "Calibrate Camera", icon: AppIcons.camera) {
                            env.currentSession.className = className
                            env.currentSession.gradeLevel = selectedGrade
                            env.currentSession.wordLength = wordLength
                            env.currentSession.topic = selectedTopic
                            env.navigationCoordinator.navigateTo(.cameraCalibration)
                        }
                    }
                    .padding(.bottom, 30)
                }
            }
        }
    }
}
