import SwiftUI

public struct SuccessView: View {
    @Environment(\.appEnvironment) private var env
    @State private var starScale: CGFloat = 0.2
    @State private var starOpacity: Double = 0.0

    public init() {}

    public var body: some View {
        ZStack {
            DynamicMeshBackground()

            VStack(spacing: 28) {
                StepProgressView(currentStep: 8, totalSteps: 11)
                    .padding(.top, 20)

                ZStack {
                    Circle()
                        .fill(AppColors.accentEmerald.opacity(0.3))
                        .frame(width: 160, height: 160)
                        .blur(radius: 20)

                    Image(systemName: AppIcons.trophy)
                        .font(.system(size: 84, weight: .black))
                        .foregroundStyle(AppColors.goldGradient)
                        .shadow(color: AppColors.accentAmber.opacity(0.8), radius: 25)
                }
                .scaleEffect(starScale)
                .opacity(starOpacity)

                VStack(spacing: 10) {
                    Text("Anagram Solved!")
                        .font(AppTypography.displayHero)
                        .foregroundColor(AppColors.textPrimary)

                    Text("Target Word: \(env.currentSession.activeChallenge?.targetWord ?? "CAT")")
                        .font(AppTypography.title1)
                        .foregroundColor(AppColors.accentEmerald)

                    Text("Perfect physical collaboration by \(env.currentSession.className)!")
                        .font(AppTypography.headline)
                        .foregroundColor(AppColors.textSecondary)
                }

                GlassCard {
                    HStack(spacing: 40) {
                        VStack(spacing: 4) {
                            Text("SOLVE TIME")
                                .font(AppTypography.caption)
                                .foregroundColor(AppColors.accentCyan)
                            Text("18.4s")
                                .font(AppTypography.title2)
                                .foregroundColor(.white)
                        }

                        Divider()
                            .frame(height: 40)
                            .background(Color.white.opacity(0.2))

                        VStack(spacing: 4) {
                            Text("ACCURACY")
                                .font(AppTypography.caption)
                                .foregroundColor(AppColors.accentCyan)
                            Text("100%")
                                .font(AppTypography.title2)
                                .foregroundColor(AppColors.accentEmerald)
                        }

                        Divider()
                            .frame(height: 40)
                            .background(Color.white.opacity(0.2))

                        VStack(spacing: 4) {
                            Text("STUDENTS")
                                .font(AppTypography.caption)
                                .foregroundColor(AppColors.accentCyan)
                            Text("\(env.visionManager.detectedStudents.count)")
                                .font(AppTypography.title2)
                                .foregroundColor(.white)
                        }
                    }
                    .padding(.vertical, 14)
                }
                .padding(.horizontal, 40)

                HStack(spacing: 20) {
                    SecondaryButton(title: "Play Again", icon: AppIcons.reload) {
                        env.navigationCoordinator.navigateTo(.humanAnagram)
                    }

                    PrimaryButton(title: "View Results", icon: AppIcons.chart) {
                        env.navigationCoordinator.navigateTo(.results)
                    }
                }
                .padding(.bottom, 30)
            }
        }
        .onAppear {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.6)) {
                starScale = 1.0
                starOpacity = 1.0
            }
        }
    }
}
