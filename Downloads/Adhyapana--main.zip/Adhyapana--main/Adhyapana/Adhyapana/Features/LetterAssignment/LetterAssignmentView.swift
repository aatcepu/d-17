import SwiftUI

public struct LetterAssignmentView: View {
    @Environment(\.appEnvironment) private var env
    @State private var activeChallenge = AppConstants.sampleChallenges[0]

    public init() {}

    public var body: some View {
        ZStack {
            DynamicMeshBackground()

            VStack(spacing: 24) {
                StepProgressView(currentStep: 6, totalSteps: 11)
                    .padding(.top, 20)

                VStack(spacing: 6) {
                    StatusBadge(text: "Target Challenge: \(activeChallenge.targetWord)", icon: AppIcons.spark, color: AppColors.primaryViolet)

                    Text("Spatial Letter Assignment")
                        .font(AppTypography.title1)
                        .foregroundColor(AppColors.textPrimary)

                    Text("Each student is assigned a scrambled floating letter based on stage position.")
                        .font(AppTypography.body)
                        .foregroundColor(AppColors.textSecondary)
                }

                GlassCard {
                    VStack(spacing: 28) {
                        Text("SCRAMBLED INITIAL STAGE LAYOUT")
                            .font(AppTypography.caption)
                            .foregroundColor(AppColors.accentCyan)

                        HStack(spacing: 36) {
                            ForEach(Array(env.visionManager.detectedStudents.enumerated()), id: \.element.id) { index, student in
                                VStack(spacing: 12) {
                                    FloatingLetterCard(
                                        letter: student.assignedLetter ?? "?",
                                        studentName: student.name,
                                        isSelected: true
                                    )

                                    Text("Slot #\(index + 1)")
                                        .font(AppTypography.monospacedBadge)
                                        .foregroundColor(AppColors.textSecondary)
                                }
                            }
                        }
                    }
                    .padding(.vertical, 20)
                }
                .padding(.horizontal, 30)

                HStack(spacing: 20) {
                    SecondaryButton(title: "Change Challenge") {
                        activeChallenge = AppConstants.sampleChallenges[(AppConstants.sampleChallenges.firstIndex(of: activeChallenge)! + 1) % AppConstants.sampleChallenges.count]
                        env.visionManager.assignLettersToStudents(for: activeChallenge.targetWord)
                    }

                    PrimaryButton(title: "Start Activity", icon: AppIcons.play) {
                        env.currentSession.activeChallenge = activeChallenge
                        env.navigationCoordinator.navigateTo(.humanAnagram)
                    }
                }
                .padding(.bottom, 30)
            }
        }
        .onAppear {
            env.visionManager.assignLettersToStudents(for: activeChallenge.targetWord)
        }
    }
}
