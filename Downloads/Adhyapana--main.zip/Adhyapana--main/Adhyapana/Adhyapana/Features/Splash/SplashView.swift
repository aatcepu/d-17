import SwiftUI

public struct SplashView: View {
    @Environment(\.appEnvironment) private var env
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    @State private var viewModel = SplashViewModel()

    public init() {}

    public var body: some View {
        ZStack {
            // Minimal Dark Mode Background: #050505 (pure minimalist solid color, no textures, no gradients)
            Color(red: 0.02, green: 0.02, blue: 0.02)
                .ignoresSafeArea()

            VStack {
                Spacer()

                // Hero Logo Anti-Gravity Assembly Container
                LogoAssemblyView(
                    letters: viewModel.letters,
                    reduceMotion: reduceMotion
                )
                // Exit transition handoff: subtle scale down, fade out, and light blur
                .scaleEffect(viewModel.isExiting ? 0.94 : 1.0)
                .opacity(viewModel.isExiting ? 0.0 : 1.0)
                .blur(radius: viewModel.isExiting ? 4.0 : 0.0)

                Spacer()
            }
        }
        .onAppear {
            viewModel.startAssembly(reduceMotion: reduceMotion) {
                env.navigationCoordinator.navigateTo(.onboarding)
            }
        }
    }
}

#Preview {
    SplashView()
}
