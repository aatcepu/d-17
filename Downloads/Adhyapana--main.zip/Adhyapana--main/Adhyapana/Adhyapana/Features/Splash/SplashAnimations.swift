import SwiftUI

public enum SplashAnimations {
    /// Apple-tuned spring physics for zero-gravity letter assembly
    public static let letterSpring = Animation.spring(
        response: 0.55,
        dampingFraction: 0.62,
        blendDuration: 0
    )

    /// Fade + scale fallback animation for Reduce Motion accessibility mode
    public static let reduceMotionFade = Animation.easeInOut(duration: 1.2)

    /// Exit transition animation when handing off to Onboarding
    public static let exitTransition = Animation.easeInOut(duration: 0.5)

    /// Generates randomized off-screen initial offsets, rotations, and Z-depth illusions for a letter
    public static func generateRandomInitialState() -> (offsetX: CGFloat, offsetY: CGFloat, rotX: Double, rotY: Double, rotZ: Double) {
        // Random off-screen bounds (between 350 to 700 pt away from center in floating directions)
        let angle = Double.random(in: 0..<(2 * .pi))
        let distance = CGFloat.random(in: 380...650)
        let offsetX = cos(angle) * distance
        let offsetY = sin(angle) * distance

        let rotX = Double.random(in: -75...75)
        let rotY = Double.random(in: -75...75)
        let rotZ = Double.random(in: -45...45)

        return (offsetX, offsetY, rotX, rotY, rotZ)
    }
}
