import SwiftUI
import UIKit

public struct LetterState: Identifiable {
    public let id: Int
    public let character: String
    public var isAssembled: Bool
    public let initialState: (offsetX: CGFloat, offsetY: CGFloat, rotX: Double, rotY: Double, rotZ: Double)

    public init(id: Int, character: String) {
        self.id = id
        self.character = character
        self.isAssembled = false
        self.initialState = SplashAnimations.generateRandomInitialState()
    }
}

@Observable
public final class SplashViewModel {
    public var letters: [LetterState] = []
    public var isAllAssembled: Bool = false
    public var isExiting: Bool = false

    private let softHaptic = UIImpactFeedbackGenerator(style: .soft)
    private let rigidHaptic = UIImpactFeedbackGenerator(style: .rigid)

    private let word = Array("ADHYĀPANA").map { String($0) }

    public init() {
        resetLetters()
    }

    public func resetLetters() {
        self.letters = word.enumerated().map { LetterState(id: $0.offset, character: $0.element) }
        self.isAllAssembled = false
        self.isExiting = false
    }

    public func startAssembly(reduceMotion: Bool, onComplete: @escaping () -> Void) {
        softHaptic.prepare()
        rigidHaptic.prepare()

        if reduceMotion {
            // Accessible Reduce Motion sequence
            withAnimation(SplashAnimations.reduceMotionFade) {
                for i in 0..<letters.count {
                    letters[i].isAssembled = true
                }
                isAllAssembled = true
            }
            softHaptic.impactOccurred()

            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
                self?.performExit(onComplete: onComplete)
            }
            return
        }

        // Staggered Zero-Gravity Anti-Gravity Assembly Sequence
        let staggerStep = 0.05 // 50ms interval between letter launches

        for index in 0..<letters.count {
            let delay = Double(index) * staggerStep

            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                guard let self = self else { return }

                withAnimation(SplashAnimations.letterSpring) {
                    self.letters[index].isAssembled = true
                }

                // Haptic feedback precisely aligned with letter landing momentum
                let isLast = (index == self.letters.count - 1)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.28) {
                    if isLast {
                        self.rigidHaptic.impactOccurred()
                        self.isAllAssembled = true

                        // Pause 0.5 seconds after full assembly before seamless transition
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.50) {
                            self.performExit(onComplete: onComplete)
                        }
                    } else {
                        self.softHaptic.impactOccurred()
                    }
                }
            }
        }
    }

    private func performExit(onComplete: @escaping () -> Void) {
        withAnimation(SplashAnimations.exitTransition) {
            self.isExiting = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.50) {
            onComplete()
        }
    }
}
