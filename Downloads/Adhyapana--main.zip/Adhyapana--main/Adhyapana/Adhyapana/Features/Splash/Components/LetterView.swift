import SwiftUI

public struct LetterView: View {
    let character: String
    let isAssembled: Bool
    let initialState: (offsetX: CGFloat, offsetY: CGFloat, rotX: Double, rotY: Double, rotZ: Double)
    let reduceMotion: Bool

    public init(
        character: String,
        isAssembled: Bool,
        initialState: (offsetX: CGFloat, offsetY: CGFloat, rotX: Double, rotY: Double, rotZ: Double),
        reduceMotion: Bool = false
    ) {
        self.character = character
        self.isAssembled = isAssembled
        self.initialState = initialState
        self.reduceMotion = reduceMotion
    }

    public var body: some View {
        Text(character)
            .font(.system(size: 42, weight: .bold, design: .default))
            .foregroundColor(.white)
            .tracking(-1.5)
            // Scale Animation: 0.75x -> 1.0x
            .scaleEffect(isAssembled ? 1.0 : (reduceMotion ? 0.95 : 0.75))
            // Opacity Animation: 20% -> 100%
            .opacity(isAssembled ? 1.0 : (reduceMotion ? 0.0 : 0.20))
            // Offset & 3D Spatial Rotation
            .offset(
                x: isAssembled ? 0 : (reduceMotion ? 0 : initialState.offsetX),
                y: isAssembled ? 0 : (reduceMotion ? 0 : initialState.offsetY)
            )
            .rotation3DEffect(
                .degrees(isAssembled ? 0 : (reduceMotion ? 0 : initialState.rotX)),
                axis: (x: 1.0, y: 0.0, z: 0.0)
            )
            .rotation3DEffect(
                .degrees(isAssembled ? 0 : (reduceMotion ? 0 : initialState.rotY)),
                axis: (x: 0.0, y: 1.0, z: 0.0)
            )
            .rotationEffect(
                .degrees(isAssembled ? 0 : (reduceMotion ? 0 : initialState.rotZ))
            )
    }
}
