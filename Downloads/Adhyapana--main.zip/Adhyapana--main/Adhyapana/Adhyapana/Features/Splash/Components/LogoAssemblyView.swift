import SwiftUI

public struct LogoAssemblyView: View {
    let letters: [LetterState]
    let reduceMotion: Bool

    public init(letters: [LetterState], reduceMotion: Bool = false) {
        self.letters = letters
        self.reduceMotion = reduceMotion
    }

    public var body: some View {
        HStack(spacing: 4) {
            ForEach(letters) { letter in
                LetterView(
                    character: letter.character,
                    isAssembled: letter.isAssembled,
                    initialState: letter.initialState,
                    reduceMotion: reduceMotion
                )
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("ADHYĀPANA")
        .accessibilityHint("Adhyāpana app title assembly animation")
    }
}
