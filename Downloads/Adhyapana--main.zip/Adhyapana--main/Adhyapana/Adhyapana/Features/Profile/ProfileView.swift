import SwiftUI

public struct ProfileView: View {
    @Environment(\.appEnvironment) private var env

    public init() {}

    public var body: some View {
        ZStack {
            DynamicMeshBackground()

            ScrollView {
                VStack(spacing: 28) {
                    StepProgressView(currentStep: 10, totalSteps: 11)
                        .padding(.top, 20)

                    VStack(spacing: 12) {
                        Image(systemName: AppIcons.profile)
                            .font(.system(size: 80))
                            .foregroundStyle(AppColors.heroGradient)

                        Text("Ms. Sharma")
                            .font(AppTypography.title1)
                            .foregroundColor(AppColors.textPrimary)

                        StatusBadge(
                            text: env.revenueCatManager.isProSubscriber ? "Adhyāpana Pro Active" : "Free Educator Tier",
                            icon: env.revenueCatManager.isProSubscriber ? "star.fill" : "lock.fill",
                            color: env.revenueCatManager.isProSubscriber ? AppColors.accentAmber : AppColors.textMuted
                        )
                    }

                    GlassCard {
                        VStack(alignment: .leading, spacing: 20) {
                            Text("CLASSROOM STATS")
                                .font(AppTypography.caption)
                                .foregroundColor(AppColors.accentCyan)

                            HStack(spacing: 20) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Total Active Sessions")
                                        .font(AppTypography.caption)
                                        .foregroundColor(AppColors.textMuted)
                                    Text("42")
                                        .font(AppTypography.title2)
                                        .foregroundColor(.white)
                                }

                                Spacer()

                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Words Solved")
                                        .font(AppTypography.caption)
                                        .foregroundColor(AppColors.textMuted)
                                    Text("284")
                                        .font(AppTypography.title2)
                                        .foregroundColor(AppColors.accentEmerald)
                                }

                                Spacer()

                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Active Students")
                                        .font(AppTypography.caption)
                                        .foregroundColor(AppColors.textMuted)
                                    Text("35")
                                        .font(AppTypography.title2)
                                        .foregroundColor(AppColors.primaryViolet)
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 30)

                    HStack(spacing: 20) {
                        SecondaryButton(title: "Back to Results") {
                            env.navigationCoordinator.navigateTo(.results)
                        }

                        PrimaryButton(title: "Explore Expansion Packs", icon: AppIcons.expansion) {
                            env.navigationCoordinator.navigateTo(.expansionPacks)
                        }
                    }
                    .padding(.bottom, 30)
                }
            }
        }
    }
}
